# 01 — Project Overview

## Vision
Construire **GUMÜÇROYAL**, une boutique e-commerce **DTC brandée** de bijoux pour femmes au Maroc, qui vend des produits sourcés (dropshipping) **au prix premium** en se présentant comme une **vraie maison de joaillerie propriétaire** de ses pièces — et non comme un revendeur.

L'objectif n'est pas "vendre un produit", c'est **vendre une marque désirable** dans laquelle la femme marocaine a confiance, au point de payer cher et de réceptionner son colis (COD) avec fierté.

## Objectifs mesurables (le site est conçu pour ça)
- **Taux de conversion** maximal (CRO 12/10).
- **AOV élevé** via offres, bundles, cross-sells, upsell post-formulaire.
- **Taux de confirmation** élevé (le client confirme l'appel COD).
- **Taux de livraison** élevé (le client réceptionne — pas de remords, pas de faux descriptif).

## Modèle
- **COD only** (paiement à la livraison). Pas de paiement en ligne.
- Trafic payant : **Snapchat Ads + TikTok Ads** (AI videos, UGC, edited videos).
- Le client commande → webhook → **Google Sheet** → l'équipe appelle pour confirmer → expédition.

## Les 3 produits (détaillés dans 06_PRODUCTS.md)
1. **Bague Lien Éternel By GUMÜÇ Royal**
2. **Collier Trèfle de Lumière By GUMÜÇ Royal**
3. **Bague Double Signature By GUMÜÇ Royal**

## Stack technique (imposée)
| Couche | Techno |
|--------|--------|
| Frontend | **Next.js (App Router) + React + TailwindCSS** |
| Backend | **Python FastAPI** |
| Base de données | **PostgreSQL** (déjà installée sur EasyPanel) |
| Hébergement | **EasyPanel** (serveur du client) |
| Conteneurisation | **Docker** (frontend + backend) |
| Versioning | **GitHub** |
| Orders sink | **Google Sheet** (via webhook + Apps Script) |
| Tracking | Meta Pixel + CAPI, TikTok Pixel + Events API, Snapchat Pixel + CAPI |

## Domaines
- Frontend : `https://gumucroyal.store`
- Backend API : `https://api.gumucroyal.store`

## Base de données (lien interne EasyPanel)
```
postgres://gumucroyal:gumucroyal@gumucroyal_database:5432/gumucroyal?sslmode=disable
```
> Nom de la base : `GUMÜÇROYAL` (utiliser `gumucroyal` comme identifiant technique partout — pas d'accents dans les identifiants SQL/env).

## Contraintes transverses
- **RTL** (arabe) + français premium pour les noms.
- Responsive mobile-first, desktop pro.
- Performance : pixels deferred, images optimisées, lazy-loading.
- Images : utiliser des **placeholders temporaires** partout (hero, produits, collection). Le client les remplacera.
- Migrations DB **automatiques au démarrage** du backend.
- Tout livré prêt à `git push` + déployer sur EasyPanel.
