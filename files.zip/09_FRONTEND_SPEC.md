# 09 — Frontend Spec (Next.js + React + Tailwind)

## Stack & libs
- **Next.js (App Router)** + **React** + **TypeScript**.
- **TailwindCSS** (avec les CSS variables de 04 mappées dans `tailwind.config`).
- **next/font** pour les polices (serif latine premium + sans UI + sans arabe).
- **next/image** pour toutes les images (placeholders inclus).
- **Framer Motion** pour les animations (reveal scroll, page load, hover).
- **lucide-react** pour les icônes.
- **zustand** (ou React Context) pour l'état du panier (cart store) — léger, simple.
- **react-hook-form** + **zod** pour le formulaire (validation 2 champs + tél marocain).
- Pas de librairie e-commerce lourde : on construit le panier nous-mêmes (3 produits).

## Structure de dossiers (frontend/)
```
frontend/
  app/
    layout.tsx                # RTL, dir="rtl", lang="ar", polices, pixels deferred
    page.tsx                  # Home
    collection/page.tsx
    produit/[slug]/page.tsx   # page produit dynamique (data depuis config)
    a-propos/page.tsx
    contact/page.tsx
    merci/page.tsx
    cgv/page.tsx
    confidentialite/page.tsx
    retours/page.tsx
    globals.css               # variables CSS + base Tailwind
  components/
    layout/Header.tsx
    layout/Footer.tsx
    layout/Logo.tsx
    home/Hero.tsx
    home/ReassuranceBar.tsx
    home/BrandSection.tsx
    home/FeaturedProducts.tsx
    home/WhyUs.tsx
    home/SocialProof.tsx
    home/HowItWorks.tsx
    product/Gallery.tsx
    product/ProductCard.tsx   # heading, subheading, stars, prix, offres, scarcity, CTA
    product/OfferSelector.tsx
    product/BenefitsSection.tsx
    product/MaterialSection.tsx
    product/ReviewsSection.tsx
    product/ComparisonTable.tsx
    product/FAQ.tsx
    product/StickyCTA.tsx
    cart/CartDrawer.tsx
    cart/CrossSell.tsx
    checkout/CheckoutPopup.tsx
    checkout/OrderForm.tsx     # 2 fields + validation MA phone
    checkout/UpsellPopup.tsx   # 69 DH, countdown 10-15s
    ui/Button.tsx ui/Stars.tsx ui/Badge.tsx ui/Countdown.tsx ui/Modal.tsx ui/Section.tsx
  lib/
    products.ts              # CONFIG des 3 produits, prix, offres, cross-sell, upsell
    cart-store.ts            # zustand store
    phone.ts                 # normalisation/validation téléphone MA -> E.164
    tracking.ts              # pixels web (deferred) + génération event_id + dedup
    api.ts                   # appel POST /api/orders vers le backend
  public/
    placeholders/            # images placeholder
  .env.example
  Dockerfile
  next.config.js
  tailwind.config.ts
  tsconfig.json
  package.json
```

## Règles de code
- **TypeScript strict**, composants fonctionnels, hooks.
- **Données produits centralisées** dans `lib/products.ts` (un seul endroit pour changer prix/offres/textes). Les pages produit lisent depuis cette config via le slug.
- **Cart store** unique (zustand) : items, add, remove, updateQty, addUpsell, totals, openDrawer state.
- **Accessibilité** : labels sur les champs, focus visible, contrastes ok.
- **RTL** : `dir="rtl"` au niveau `<html>`, classes Tailwind logiques (ps/pe, ms/me) plutôt que left/right en dur quand possible.
- **Pas de secrets côté client** : seules les variables `NEXT_PUBLIC_*` sont exposées (IDs de pixels publics). Le token CAPI reste **backend**.
- **Performance** : 
  - Pixels chargés en **deferred** (après interaction ou via `next/script` strategy `afterInteractive`/`lazyOnload`).
  - Images optimisées + lazy.
  - Composants lourds (popups) chargés à la demande (dynamic import).
- **Config via env** : URL du backend (`NEXT_PUBLIC_API_URL`), IDs pixels publics, etc. (voir 13).

## Variables d'env frontend (NEXT_PUBLIC_*)
Voir `.env.example` détaillé dans 13. Inclut : `NEXT_PUBLIC_API_URL`, `NEXT_PUBLIC_META_PIXEL_ID`, `NEXT_PUBLIC_TIKTOK_PIXEL_ID`, `NEXT_PUBLIC_SNAPCHAT_PIXEL_ID`, `NEXT_PUBLIC_SITE_URL`.

## Détails UI à respecter
- Sections desktop **alternées texte/image** (et inversées), comme demandé.
- CTA = élément le plus visible, dégradé or.
- Cart drawer + popups animés (Framer Motion).
- Sticky CTA mobile sur pages produit.
- Tout le copy émotionnel en **darija (arabe)**, noms produits en **français**.
