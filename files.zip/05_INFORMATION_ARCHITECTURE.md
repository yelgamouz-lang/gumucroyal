# 05 — Information Architecture (Pages, Header, Footer)

## Header (toutes les pages)
Disposition (RTL — adapter le sens) :
- **Logo** : cercle teinté brand-gold + logo texte "GUMÜÇROYAL" en police premium.
- **Menu** de navigation : الرئيسية (Accueil) · المجموعة (Collection) · من نحن (À propos) · اتصلي بنا (Contact).
- **Panier (cart)** : icône avec compteur d'articles → ouvre le **cart drawer**.
- Sticky en haut, fond noir légèrement translucide au scroll (backdrop blur léger).
- Mobile : logo + burger menu + cart.

## Pages

### 1. Home page (`/`)
Structure recommandée (de haut en bas), pensée pour présenter la marque + convertir :
1. **Hero** : grand visuel (placeholder), titre serif + accroche darija (« بريق ذهبي كيدوم »), CTA principal (« اكتشفي المجموعة »).
2. **Bandeau réassurance** (barre de badges défilante) : 316L · ما كيصدأش · الدفع عند الاستلام · توصيل لكل المدن · ضمان 30 يوم.
3. **Section marque** (texte/image alternés) : qui est GUMÜÇROYAL, positionnement, promesse.
4. **Produits vedettes** : les 3 produits en cartes (image, nom FR, prix, ★, CTA "اكتشفي").
5. **Pourquoi GUMÜÇROYAL** (texte/image inversés) : durabilité, hypoallergénique, dorure or fin — chaque point avec preuve.
6. **Social proof** : note moyenne 4.8★, carrousel d'avis clientes avec photos (UGC), compteur "+X clientes".
7. **Section "Comment ça marche / كيفاش كتخدم"** : 1) كتختاري 2) كتطلبي بـ COD 3) كنعيطو ليك نأكدو 4) كيوصلك. (rassure sur le COD).
8. **Bandeau garantie / offre** : ضمان + livraison + emballage cadeau.
9. **CTA final** + **Footer**.

### 2. Collection page (`/collection`)
- Titre + intro courte.
- Grille des 3 produits (cartes complètes : image, nom, prix barré + prix offre, ★, CTA).
- Badges réassurance répétés.

### 3. Product / Landing pages (`/produit/[slug]`)
Une page dédiée par produit (3 au total). Structure CRO complète détaillée dans **07_CRO_AND_CONVERSION.md**. En résumé :
- Galerie 3-4 images (placeholders) + **product card** (heading, subheading, ★, prix/offres, scarcity, CTA add-to-cart).
- Sélecteur d'offres (1 pièce / 2 pièces -X% / 3 pièces -Y%) → AOV.
- Sections de vente alternées texte/image (bénéfices, preuve, ingrédients/matière, avis, FAQ, garantie).
- CTA → ajoute l'offre choisie au panier → ouvre le **cart drawer**.

### 4. About us (`/a-propos`)
- Brand story en darija (voir 02), valeurs, engagement qualité, photo/atelier (placeholder), réassurance.

### 5. Contact (`/contact`)
- Coordonnées, **WhatsApp** (CTA direct), formulaire de contact simple, horaires, réseaux sociaux (TikTok/Snap/Insta).

## Footer (toutes les pages)
- **Colonne marque** : logo + courte phrase + réseaux (TikTok, Snapchat, Instagram).
- **Colonne navigation** : liens vers toutes les pages.
- **Colonne aide** : Contact, WhatsApp, Livraison, Retours/Garantie, FAQ.
- **Colonne légal** : Conditions générales, Politique de confidentialité, Politique de retour.
- **Bandeau bas** : © GUMÜÇROYAL 2026 · "صنع بكل حب فالمغرب" · badges paiement COD / livraison.
- Réassurance COD + numéro WhatsApp visible.

## Routes récapitulatives
| Route | Page |
|-------|------|
| `/` | Home |
| `/collection` | Collection |
| `/produit/bague-lien-eternel` | Produit 1 |
| `/produit/collier-trefle-de-lumiere` | Produit 2 |
| `/produit/bague-double-signature` | Produit 3 |
| `/a-propos` | About |
| `/contact` | Contact |
| `/merci` | Thank you page (post-commande) |
| (légal) `/cgv`, `/confidentialite`, `/retours` | Pages légales |
