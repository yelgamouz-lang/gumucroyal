# GUMÜÇROYAL — Documentation Master (pour l'AI Coder)

Bienvenue. Ce dossier `docs/` contient **toute** la spécification nécessaire pour construire la boutique e-commerce DTC brandée **GUMÜÇROYAL** (bijoux femme, Maroc, COD).

L'AI coder DOIT lire les fichiers dans l'ordre avant d'écrire la moindre ligne de code.

## Ordre de lecture

| # | Fichier | Contenu |
|---|---------|---------|
| 00 | `00_README.md` | Ce fichier — index + règles d'or |
| 01 | `01_PROJECT_OVERVIEW.md` | Vision, objectifs, contraintes, stack |
| 02 | `02_BRAND_POSITIONING.md` | Positionnement, brand story, autorité, "owner not dropshipper" |
| 03 | `03_ICP_AND_PSYCHOLOGY.md` | Client cible (ICP), douleurs, désirs, langage darija, émotions |
| 04 | `04_DESIGN_SYSTEM.md` | Couleurs, typographie, logo, composants, layout, responsive |
| 05 | `05_INFORMATION_ARCHITECTURE.md` | Toutes les pages, header, footer, navigation |
| 06 | `06_PRODUCTS.md` | Les 3 produits, copy, prix, offres, cross-sells, upsell |
| 07 | `07_CRO_AND_CONVERSION.md` | CRO 12/10, sections de vente, social proof, scarcity, trust |
| 08 | `08_CHECKOUT_AND_COD_FLOW.md` | Cart drawer, checkout popup, form 2 champs, upsell post-form, thank you |
| 09 | `09_FRONTEND_SPEC.md` | Next.js, React, Tailwind, libs, structure dossiers, règles de code |
| 10 | `10_BACKEND_SPEC.md` | FastAPI, PostgreSQL, migrations auto, endpoints, env vars |
| 11 | `11_TRACKING_PIXELS_CAPI.md` | Meta/TikTok/Snap Pixels + CAPI, hashing, dedup, deferred loading |
| 12 | `12_GOOGLE_SHEET_INTEGRATION.md` | Webhook → Google Sheet, Apps Script JS, colonnes, template |
| 13 | `13_DEPLOYMENT_EASYPANEL.md` | Docker, GitHub, EasyPanel, domaines, env.example |
| 14 | `14_DELIVERABLES_CHECKLIST.md` | Liste exacte de ce que l'AI coder doit livrer |

## RÈGLES D'OR (non négociables)

1. **Langue du site : Darija marocaine en alphabet arabe** pour le copy émotionnel + **français premium** pour les noms produits et termes de marque. Le site est **RTL** (right-to-left) car l'arabe domine.
2. **C'est une MARQUE, pas un dropshipper.** Aucune trace de dropshipping. Le site doit donner l'impression que GUMÜÇROYAL fabrique/possède ses bijoux.
3. **COD uniquement.** Pas de paiement en ligne. Formulaire = 2 champs (nom + téléphone marocain valide).
4. **Honnêteté produit = protection légale + delivery rate.** On dit **"acier inoxydable doré à l'or fin"** et **"zircons / cristaux"**, JAMAIS "or massif" ni "diamants". Faux descriptif = compte pub banni + retours COD.
5. **Performance d'abord.** Pixels web en *deferred*. Images optimisées. Le site doit être rapide sur mobile 4G marocain.
6. **Mobile-first.** La majorité du trafic vient de Snapchat/TikTok sur mobile. Desktop doit être pro aussi (sections alternées texte/image).
7. **Déduplication tracking parfaite** : même `event_id` côté navigateur (Pixel) et serveur (CAPI).
8. **Tout doit être prêt à déployer** : Docker, env.example, migrations auto au démarrage du backend.

## Sécurité & conformité
- Ne jamais logger les numéros de téléphone en clair dans les logs applicatifs.
- Hasher (SHA-256) les PII uniquement pour CAPI (jamais pour le pixel web).
- Valider et nettoyer toutes les entrées du formulaire côté backend (pas seulement frontend).
- Rate-limiting sur l'endpoint de création de commande (anti-spam/anti-bot).
