# 02 — Brand Positioning & Authority

## Le principe central : "Owner, not dropshipper"
Tout sur le site doit dire, implicitement : *« Ces bijoux sont les NÔTRES. Nous sommes une maison. »*
Aucune mention, image, formulation ou détail qui trahirait du dropshipping (pas de "expédié sous 15-25 jours", pas de packaging AliExpress, pas de photos génériques mal cadrées).

## Positionnement
**GUMÜÇROYAL = la maison de joaillerie accessible qui rend le luxe doré porté au quotidien — sans qu'il ternisse, sans qu'il noircisse la peau, sans le prix de l'or véritable.**

Trois piliers :
1. **Élégance royale** — esthétique noire + or, inspiration ottomane/luxe, nom qui sonne grand.
2. **Durabilité réelle** — acier inoxydable 316L doré à l'or fin : ne ternit pas, hypoallergénique. (C'est l'argument qui tue la peur n°1 de la cliente marocaine.)
3. **Confiance & proximité** — marque marocaine qui parle darija, livraison COD, SAV humain WhatsApp.

## Brand story (à adapter en darija sur la page About)
GUMÜÇROYAL est née d'une idée simple : chaque femme mérite l'éclat de l'or au quotidien, sans compromis et sans peur d'abîmer sa peau. Nous sélectionnons un acier inoxydable de qualité chirurgicale (316L) que nous habillons d'une dorure à l'or fin, pour des pièces qui gardent leur éclat saison après saison. Des créations pensées comme des signatures — pas comme des bijoux jetables.

> Note : raconter une histoire de **sélection / exigence / maison**, jamais de fabrication mensongère. On ne ment pas (on ne dit pas "fabriqué dans notre atelier à Fès" si c'est faux). On valorise la **sélection rigoureuse** et la **dorure**. C'est crédible ET honnête.

## Éléments d'autorité & de réassurance (à intégrer partout)
La femme marocaine achète cher quand elle voit ces signaux :
- **Acier inoxydable 316L** (gage qualité chirurgicale) — badge récurrent.
- **"Ne ternit pas / لا يصدأ"** — promesse répétée.
- **"Hypoallergénique / ما كيحسّسش"** — pour peaux sensibles.
- **Garantie** (ex. "30 jours satisfait ou remboursé / ضمان").
- **Paiement à la livraison / الدفع عند الاستلام** — zéro risque pour la cliente.
- **Livraison partout au Maroc / توصيل لجميع المدن**.
- **+X clientes satisfaites** (social proof chiffré).
- **Avis clientes avec photos** (UGC).
- **Note moyenne ★ 4.8/5**.
- **SAV WhatsApp** (numéro visible) — humain, rassurant.
- **Emballage cadeau offert / تغليف هدية** — perçu premium.

## Ton de marque
- **Premium mais chaleureux.** Pas froid, pas distant. On parle à une amie qui a du goût.
- **Darija naturelle** pour l'émotion, **français** pour les noms de pièces ("Lien Éternel").
- **Fier, jamais honteux.** On vend la beauté et la confiance, pas un complexe.

## Ce qu'on ne fait JAMAIS
- Dire "diamants" (ce sont des zircons) ou "or massif" (c'est de l'acier doré).
- Promettre des effets médicaux.
- Copier une marque déposée (s'inspirer de l'esthétique iconique est ok ; reproduire un logo/nom déposé, non).
- Laisser un seul élément qui sente le dropshipping.
