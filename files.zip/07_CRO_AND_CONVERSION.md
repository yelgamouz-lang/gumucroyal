# 07 — CRO 12/10 & Sections de Conversion

Objectif : page produit qui **convertit, rassure, et fait monter le panier**, en darija, pour l'ICP marocaine COD.

## Anatomie d'une page produit (ordre conseillé)

1. **Galerie + Product Card (above the fold)**
   - Galerie 3-4 images (placeholders), miniatures.
   - **Heading** (nom FR serif) + **By GUMÜÇ Royal** + **subheading** darija.
   - **Étoiles** ★ 4.8 + "(X avis)".
   - **Prix** : prix offre en gros + prix barré + % de réduction + économie en DH.
   - **Sélecteur d'offres** (1/2/3 pièces — voir 06), offre du milieu pré-sélectionnée.
   - **Scarcity** : « بقاو غير 7 قطع » (barre de stock animée), « العرض كيسالي قريب » (mini compte à rebours soft).
   - **CTA principal** : « زيدي للسلة » → add-to-cart de l'offre choisie → ouvre cart drawer.
   - **Badges réassurance** juste sous le CTA : COD · ما كيصدأش · ما كيحسّسش · ضمان 30 يوم · توصيل لكل المدن.
   - Sur mobile : **CTA sticky** en bas de l'écran.

2. **Barre de confiance** (icônes) : livraison, COD, garantie, qualité 316L.

3. **Bénéfices (section texte/image)** : 3-4 bénéfices émotionnels backés par la preuve (durabilité, éclat, hypoallergénique, port quotidien). Alterner texte/image.

4. **"المادة / La matière" (section image/texte inversée)** : expliquer l'acier 316L + dorure or fin, pourquoi ça ne ternit pas, pourquoi c'est sans risque pour la peau. C'est la "science/ingredients" qui crédibilise.

5. **Avant/Après ou "en situation"** : la pièce portée, gros plan sur l'éclat (placeholders). Renforce le désir.

6. **Social proof massif** :
   - Note globale ★ 4.8/5 + distribution.
   - Avis clientes avec **photos** (UGC), prénoms + villes marocaines.
   - Compteur "+X clientes satisfaites".
   - Captures de messages WhatsApp/DM de clientes contentes (placeholders).

7. **Comparatif** (optionnel, fort en CRO) : tableau "GUMÜÇROYAL vs bijoux ordinaires" (ne ternit pas vs noircit, hypoallergénique vs irrite, COD vs prépaiement risqué, garantie vs aucune).

8. **FAQ** (accordéon, darija) : 
   - واش كيصدأ؟ — لا، ستانلس ستيل 316L.
   - واش كيكحّل اليد؟ — لا، هايبوالرجينيك.
   - كيفاش كنخلّص؟ — عند الاستلام.
   - شحال كياخد التوصيل؟ — 24–72 ساعة حسب المدينة.
   - واش كاين ضمان؟ — ضمان 30 يوم.

9. **Garantie / réassurance finale** + **CTA répété**.

10. **Cross-sell teaser** : "كمّلي إطلالتك" (aussi présent dans le drawer).

## Leviers CRO transverses (à appliquer partout)
- **Ancrage prix** : toujours prix barré + économie chiffrée.
- **Scarcity honnête** : stock limité, offre limitée (compte à rebours doux, pas mensonger/agressif).
- **Risque inversé** : COD + garantie 30 jours = "zéro risque pour toi".
- **Preuve sociale omniprésente** : étoiles, avis, compteurs, photos clientes.
- **Réduction de friction** : formulaire 2 champs, CTA clairs, parcours court.
- **Autorité** : badges 316L, hypoallergénique, "maison" GUMÜÇROYAL.
- **Urgence à la fin du form** : upsell 69 DH avec compte à rebours.
- **Mobile sticky CTA** : le bouton d'achat toujours accessible.

## Éléments qui montent confirmation & delivery rate
- COD très visible partout (« خلّصي منين توصلك »).
- Étape "كنعيطو ليك نأكدو الطلب" expliquée → la cliente s'attend à l'appel = meilleure confirmation.
- Délais de livraison réalistes affichés (pas de promesse intenable).
- Descriptions honnêtes (acier doré, zircons) → ce qu'elle reçoit = ce qu'on a promis = elle garde le colis.
- WhatsApp visible → elle peut poser une question avant/après = confiance.
- Emballage cadeau premium annoncé → effet "waouh" à la réception.
