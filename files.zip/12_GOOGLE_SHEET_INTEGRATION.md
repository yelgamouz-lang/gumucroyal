# 12 — Intégration Google Sheet (Webhook + Apps Script)

But : chaque commande validée arrive **dans un Google Sheet** via un webhook, pour que l'équipe appelle et confirme (COD).

## Flux
```
Frontend → POST /api/orders (backend FastAPI)
   → enregistre en PostgreSQL
   → POST webhook → Google Apps Script (Web App) → écrit une ligne dans le Sheet
```

## Côté backend
- Service `services/sheets.py` :
  - Construit un JSON avec toutes les infos de commande.
  - `POST` vers `GOOGLE_SHEET_WEBHOOK_URL` (l'URL de déploiement du Apps Script).
  - Inclut un **secret** `GOOGLE_SHEET_WEBHOOK_SECRET` (vérifié côté Apps Script) pour empêcher les écritures non autorisées.
  - Appel en tâche de fond (ne bloque pas la réponse au client) + retry simple si échec.

## Payload envoyé au Sheet (JSON)
```json
{
  "secret": "<GOOGLE_SHEET_WEBHOOK_SECRET>",
  "order_id": "uuid",
  "created_at": "2026-06-02T10:30:00Z",
  "full_name": "سعاد ...",
  "phone_local": "0612345678",
  "phone_e164": "+212612345678",
  "items": "Bague Lien Éternel x2 (2 pièces) | + Upsell Collier 69 DH",
  "total_amount": 468.00,
  "currency": "MAD",
  "has_upsell": true,
  "source": "tiktok",
  "page_url": "https://gumucroyal.store/produit/bague-lien-eternel",
  "status": "new"
}
```

## Google Apps Script (le fichier JS à coller dans Google Sheet)
Fournir un fichier `google-apps-script.gs` (livrable) qui :
1. Reçoit le POST (`doPost(e)`).
2. Vérifie le `secret`.
3. Parse le JSON.
4. Ajoute une ligne dans l'onglet "Orders".
5. Répond `200 {ok:true}`.

Squelette à livrer :
```javascript
const SHEET_NAME = "Orders";
const SECRET = "REMPLACER_PAR_LE_MEME_SECRET_QUE_LE_BACKEND";

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents);
    if (body.secret !== SECRET) {
      return ContentService.createTextOutput(JSON.stringify({ ok:false, error:"unauthorized" }))
        .setMimeType(ContentService.MimeType.JSON);
    }
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(["order_id","created_at","full_name","phone_local","phone_e164",
        "items","total_amount","currency","has_upsell","source","page_url","status"]);
    }
    sheet.appendRow([
      body.order_id, body.created_at, body.full_name, body.phone_local, body.phone_e164,
      body.items, body.total_amount, body.currency, body.has_upsell, body.source,
      body.page_url, body.status
    ]);
    return ContentService.createTextOutput(JSON.stringify({ ok:true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ ok:false, error:String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
```

## Colonnes du Sheet (onglet "Orders")
`order_id | created_at | full_name | phone_local | phone_e164 | items | total_amount | currency | has_upsell | source | page_url | status`

## Déploiement Apps Script
1. Ouvrir le Google Sheet → Extensions → Apps Script.
2. Coller `google-apps-script.gs`, mettre le même `SECRET` que le backend.
3. Déployer en **Web App** (Exécuter en tant que : moi ; Accès : tout le monde).
4. Copier l'URL `/exec` → la mettre dans `GOOGLE_SHEET_WEBHOOK_URL` (env backend).

## Livrables liés (voir 14)
- `google-apps-script.gs`
- `sheet_template.csv` (en-têtes des colonnes, pour préparer le Sheet)
