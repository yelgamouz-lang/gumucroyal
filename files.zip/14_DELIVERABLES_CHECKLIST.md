# 14 — Checklist des Livrables (ce que l'AI coder DOIT produire)

## Structure racine du repo
```
/
├── frontend/            # Next.js + React + Tailwind (voir 09)
├── backend/             # FastAPI + PostgreSQL (voir 10)
├── google-apps-script.gs   # script à coller dans Google Sheet (voir 12)
├── sheet_template.csv   # en-têtes des colonnes du Sheet
├── docs/                # cette documentation
├── README.md            # instructions complètes (install, env, déploiement EasyPanel)
└── .gitignore
```

## Frontend (à livrer)
- [ ] Toutes les pages (Home, Collection, 3× Produit, About, Contact, Merci, légales).
- [ ] Header (logo cercle + texte, menu, cart) + Footer complet.
- [ ] Cart drawer avec cross-sells.
- [ ] Checkout popup (order summary + social proof + scarcity + form 2 champs).
- [ ] Validation téléphone marocain (frontend) + normalisation E.164.
- [ ] Upsell popup 69 DH avec compte à rebours 10–15s.
- [ ] Thank you page.
- [ ] `lib/products.ts` (config des 3 produits, prix, offres, cross-sell, upsell).
- [ ] `lib/cart-store.ts`, `lib/phone.ts`, `lib/tracking.ts`, `lib/api.ts`.
- [ ] Pixels web (Meta/TikTok/Snap) en **deferred** + génération `event_id` + dedup.
- [ ] Design system appliqué (couleurs, polices, RTL, sections alternées).
- [ ] Responsive mobile-first + sticky CTA mobile.
- [ ] Images **placeholders** partout.
- [ ] `Dockerfile`, `.env.example`, `next.config.js`, `tailwind.config.ts`, `package.json`.

## Backend (à livrer)
- [ ] App FastAPI avec `GET /api/health` et `POST /api/orders`.
- [ ] Modèles `Order` + `OrderItem` + migrations Alembic.
- [ ] **Migrations automatiques au démarrage**.
- [ ] `services/phone.py` (validation/normalisation MA → E.164).
- [ ] `services/sheets.py` (webhook Google Sheet + secret + retry).
- [ ] `services/tracking_capi.py` (Meta + TikTok + Snapchat, hashing SHA-256, dedup event_id).
- [ ] `services/hashing.py`.
- [ ] CORS configuré pour `gumucroyal.store`.
- [ ] Rate-limiting sur `/api/orders`.
- [ ] `Dockerfile`, `requirements.txt`, `alembic.ini`, `.env.example`.

## Intégration Google Sheet (à livrer)
- [ ] `google-apps-script.gs` (doPost + vérif secret + append row).
- [ ] `sheet_template.csv` (en-têtes des colonnes).
- [ ] Instructions de déploiement du Apps Script (dans README).

## Fichiers de config / env (à livrer)
- [ ] `frontend/.env.example` (NEXT_PUBLIC_*).
- [ ] `backend/.env.example` (DATABASE_URL, webhook, tokens CAPI…).
- [ ] Liste claire dans le README des variables à mettre dans EasyPanel.

## CSV (à livrer)
- [ ] `sheet_template.csv` : en-têtes des colonnes du Google Sheet.
- [ ] (optionnel) `products.csv` : les 3 produits + prix + offres, pour référence/import.

## Documentation (à livrer)
- [ ] `README.md` racine : 
  - prérequis, install locale (frontend + backend),
  - variables d'env,
  - lancement Docker,
  - déploiement EasyPanel pas à pas,
  - déploiement du Google Apps Script,
  - configuration des pixels + tokens CAPI + tests (Test Event Codes).

## Qualité / conformité (vérifier avant de livrer)
- [ ] Site **RTL**, copy en **darija**, noms produits en **français**.
- [ ] Aucun "or massif"/"diamant" — uniquement "acier doré à l'or fin"/"zircons".
- [ ] Aucun élément qui trahit le dropshipping.
- [ ] COD only, form 2 champs, tél MA validé.
- [ ] Pixels deferred, dédup web+CAPI OK, hashing CAPI correct (E.164 + SHA-256).
- [ ] Migrations auto au démarrage testées.
- [ ] Tout buildable en Docker et déployable sur EasyPanel sans modif manuelle de code (tout via env).
```
