# 11 — Tracking : Pixels Web + CAPI (Meta, TikTok, Snapchat)

But : tracking complet, **déduplication parfaite**, **pixels web deferred** (perf), **CAPI côté serveur** avec hashing correct. Spécifications confirmées par recherche (2026).

## Principe de déduplication (CRITIQUE)
Pour CHAQUE événement (surtout `Purchase`) :
- Générer **un seul `event_id`** côté frontend au moment de l'action.
- L'envoyer **à la fois** au **pixel web** (navigateur) ET au **backend** qui le transmet en **CAPI**.
- Meta/TikTok/Snap dédupliquent quand **event_name + event_id** correspondent entre web et serveur.
- Stocker l'`event_id` dans la commande (déjà prévu en DB).

## Règles de hashing (CAPI uniquement — JAMAIS le pixel web)
- **Pixel web** : ne hash RIEN (le navigateur envoie les identifiants cookies tels quels).
- **CAPI (serveur)** : hasher les **PII** en **SHA-256** après **normalisation** :
  - **Téléphone** : format **E.164** d'abord (ex. `+2126XXXXXXXX`), puis SHA-256.
  - **Email** : (on n'en collecte pas dans ce funnel COD 2 champs — donc en général absent).
  - **Prénom/Nom** : minuscules + trim, puis SHA-256 (optionnel, améliore le matching).
- **Ne PAS hasher** : `fbp`, `fbc`, `ttclid`, `sc_click_id`, IP, user agent (ce sont des identifiants techniques, envoyés en clair).

> Note téléphone : le format **E.164 inclut le `+` et l'indicatif pays** (Maroc = `212`). Donc `0612345678` → `+212612345678`. C'est cette valeur normalisée qu'on hash. (Couvre l'exigence "TikTok peut avoir besoin du + devant le numéro".)

## Identifiants à capturer côté navigateur (et passer au backend)
- `fbp` (cookie `_fbp`), `fbc` (cookie `_fbc` / param `fbclid`) — pour Meta.
- `ttclid` (param d'URL / cookie `_ttp`) — pour TikTok.
- `sc_click_id` / `ScCid` — pour Snapchat.
- `event_id`, `event_source_url` (page), `user_agent`, IP (l'IP est lue côté serveur depuis la requête).

## Événements à tracker
| Événement | Quand | Web pixel | CAPI |
|-----------|-------|-----------|------|
| PageView | chargement page | ✅ | optionnel |
| ViewContent | page produit | ✅ | optionnel |
| AddToCart | ajout panier | ✅ | optionnel |
| InitiateCheckout | ouverture checkout popup | ✅ | optionnel |
| Purchase | commande confirmée (thank you) | ✅ | ✅ (obligatoire) |

> Priorité absolue : **Purchase** bien dédupliqué web+CAPI (c'est le signal d'optimisation). Les autres events web suffisent souvent, mais prévoir l'archi pour envoyer aussi en CAPI si besoin.

## Pixels web (frontend) — DEFERRED
- Charger les scripts pixels en **deferred** : via `next/script` avec `strategy="afterInteractive"` ou `lazyOnload`, ou après la première interaction, pour ne pas ralentir le rendu initial.
- Init des 3 pixels avec leurs IDs publics (`NEXT_PUBLIC_*`).
- Exposer des helpers `track(eventName, payload, eventId)` dans `lib/tracking.ts`.
- Respecter un éventuel consentement (cookie banner si ajouté plus tard).

## CAPI (backend) — payloads

### Meta Conversions API
- Endpoint : `https://graph.facebook.com/v20.0/{META_PIXEL_ID}/events?access_token={META_CAPI_TOKEN}`
- Body :
```json
{
  "data": [{
    "event_name": "Purchase",
    "event_time": 1743782400,
    "event_id": "<MEME_EVENT_ID_QUE_LE_PIXEL>",
    "action_source": "website",
    "event_source_url": "https://gumucroyal.store/merci",
    "user_data": {
      "ph": "<sha256(E.164 phone)>",
      "fn": "<sha256(prenom lowercased)>",
      "client_ip_address": "<ip>",
      "client_user_agent": "<ua>",
      "fbp": "<fbp en clair>",
      "fbc": "<fbc en clair>"
    },
    "custom_data": { "currency": "MAD", "value": 399.00 }
  }],
  "test_event_code": "<META_TEST_EVENT_CODE si test>"
}
```
- `event_time` = Unix timestamp **en secondes**.

### TikTok Events API
- Endpoint : `https://business-api.tiktok.com/open_api/v1.3/event/track/`
- Header : `Access-Token: {TIKTOK_CAPI_TOKEN}`
- Body (structure 2026) :
```json
{
  "event_source": "web",
  "event_source_id": "<TIKTOK_PIXEL_ID>",
  "test_event_code": "<optionnel>",
  "data": [{
    "event": "CompletePayment",
    "event_time": 1743782400,
    "event_id": "<MEME_EVENT_ID>",
    "user": {
      "phone": "<sha256(E.164 phone)>",
      "ttclid": "<ttclid en clair>",
      "ip": "<ip>",
      "user_agent": "<ua>"
    },
    "properties": { "currency": "MAD", "value": 399.00 }
  }]
}
```
- Téléphone en **E.164** puis **SHA-256** (TikTok exige SHA-256, pas MD5).

### Snapchat Conversions API
- Endpoint : `https://tr.snapchat.com/v3/{SNAPCHAT_PIXEL_ID}/events?access_token={SNAPCHAT_CAPI_TOKEN}` (vérifier la version courante de l'API au moment du build).
- Body : structure équivalente — `event_name: "PURCHASE"`, `event_id`, `hashed_phone_number` (SHA-256 sur E.164), `hashed_email` (si dispo), identifiants click en clair, `timestamp`, `currency`, `price`.

> **L'AI coder doit vérifier la version exacte des endpoints/champs au moment du build** (les API évoluent) et utiliser le Test Event Tool de chaque plateforme pour valider avant prod.

## Validation
- Utiliser les **Test Event Codes** de chaque plateforme pour vérifier la réception.
- Vérifier l'**Event Match Quality (EMQ)** Meta/TikTok après 48h.
- Vérifier que **web et serveur ne comptent pas double** (dédup OK = bon event_id partagé).
