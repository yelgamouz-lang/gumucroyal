# 13 — Déploiement (Docker, GitHub, EasyPanel)

## Vue d'ensemble
- 2 services Docker : **frontend** (Next.js) et **backend** (FastAPI).
- PostgreSQL **déjà installé** sur EasyPanel.
- Domaines : `gumucroyal.store` (front) et `api.gumucroyal.store` (back).
- Code poussé sur **GitHub** → EasyPanel build & deploy depuis le repo (ou via image Docker).

## Dockerfiles
- `frontend/Dockerfile` : build Next.js en mode production (multi-stage, `next build` → `next start`), expose le port (ex. 3000).
- `backend/Dockerfile` : Python slim, install requirements, lance Uvicorn/Gunicorn (ex. port 8000), exécute les migrations au démarrage.

## .env.example — FRONTEND
```env
# URL publique du backend
NEXT_PUBLIC_API_URL=https://api.gumucroyal.store
# URL du site
NEXT_PUBLIC_SITE_URL=https://gumucroyal.store
# Pixels (IDs publics — pas de secret ici)
NEXT_PUBLIC_META_PIXEL_ID=
NEXT_PUBLIC_TIKTOK_PIXEL_ID=
NEXT_PUBLIC_SNAPCHAT_PIXEL_ID=
```

## .env.example — BACKEND
```env
# Base de données (lien interne EasyPanel)
DATABASE_URL=postgres://gumucroyal:gumucroyal@gumucroyal_database:5432/gumucroyal?sslmode=disable

# CORS
FRONTEND_ORIGIN=https://gumucroyal.store

# Google Sheet webhook
GOOGLE_SHEET_WEBHOOK_URL=
GOOGLE_SHEET_WEBHOOK_SECRET=

# Meta CAPI
META_PIXEL_ID=
META_CAPI_TOKEN=
META_TEST_EVENT_CODE=

# TikTok Events API
TIKTOK_PIXEL_ID=
TIKTOK_CAPI_TOKEN=
TIKTOK_TEST_EVENT_CODE=

# Snapchat CAPI
SNAPCHAT_PIXEL_ID=
SNAPCHAT_CAPI_TOKEN=
SNAPCHAT_TEST_EVENT_CODE=
```

> ⚠️ `DATABASE_URL` utilise le driver `postgres://`. Selon la lib Python (SQLAlchemy + psycopg v3), adapter en `postgresql+psycopg://...` au besoin **dans le code** (garder la valeur EasyPanel telle quelle dans l'env, convertir au runtime). Garder `sslmode=disable` car lien interne.

## Étapes EasyPanel (à documenter dans le README livré)
1. Créer le service **backend** depuis le repo GitHub (dossier `backend/`), renseigner les env vars backend, exposer `api.gumucroyal.store`, port 8000, healthcheck `/api/health`.
2. Créer le service **frontend** (dossier `frontend/`), renseigner les env vars `NEXT_PUBLIC_*`, exposer `gumucroyal.store`, port 3000.
3. Vérifier que le backend voit la base via `gumucroyal_database` (réseau interne EasyPanel).
4. Le backend exécute les **migrations automatiquement** au démarrage (créer les tables).
5. Configurer les domaines + SSL (Let's Encrypt EasyPanel).
6. Tester : commande de bout en bout → ligne dans Google Sheet + events de test reçus.

## GitHub
- Un repo (ou monorepo) avec `frontend/` et `backend/`.
- `.gitignore` : `node_modules`, `.next`, `__pycache__`, `.env`, etc.
- Ne JAMAIS committer les vrais `.env` (seulement `.env.example`).
- README racine avec instructions de déploiement.

## Performance prod
- Frontend : build optimisé, images `next/image`, pixels deferred.
- Backend : workers Gunicorn adaptés, appels CAPI/Sheet en tâche de fond.
