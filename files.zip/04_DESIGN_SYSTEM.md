# 04 — Design System

## Direction artistique
**Luxe sombre & doré.** Inspiration : écrin de joaillerie, fond noir profond, fumée, lumière chaude sur l'or. Élégant, premium, féminin, royal. (Cohérent avec les visuels produits déjà fournis : fond noir + fumée + bijou doré.)

## Palette de couleurs (CSS variables)
```css
:root {
  --color-bg:        #0B0B0D;  /* noir profond (fond principal) */
  --color-bg-soft:   #141417;  /* sections alternées */
  --color-surface:   #1B1B1F;  /* cartes, drawer */
  --color-gold:      #C9A227;  /* or principal (brand color) */
  --color-gold-soft: #E6C766;  /* or clair / hover / dégradé */
  --color-gold-deep: #8C6B14;  /* or foncé / ombres dorées */
  --color-cream:     #F5EFE0;  /* texte clair premium */
  --color-text:      #EDEDED;  /* texte courant sur fond noir */
  --color-text-mut:  #A1A1A1;  /* texte secondaire */
  --color-success:   #3FB984;  /* validations */
  --color-danger:    #E05656;  /* erreurs */
  --color-line:      #2A2A2E;  /* bordures discrètes */
}
```
> **Brand color = or `--color-gold` (#C9A227)**. Le logo dans le header est dans un **cercle** rempli/contouré de cette couleur.

## Typographie
- **Police latine premium (titres / noms de produits)** : une serif élégante type *Cormorant Garamond* ou *Playfair Display* (via next/font Google). Donne le côté joaillerie.
- **Police latine UI / corps** : une sans-serif raffinée (ex. *Manrope* ou *Jost*) — PAS Inter/Roboto/Arial.
- **Police arabe (darija)** : une police arabe élégante et lisible (ex. *Tajawal*, *Cairo* ou *IBM Plex Sans Arabic* via Google Fonts). Choisir celle qui rend le mieux en RTL premium.
- Hiérarchie : titres en serif latine + or ; corps arabe en sans arabe claire.

## Logo (header)
- **À gauche** (mais en RTL = côté début de lecture) : **LOGO dans un cercle** bordé/teinté en `--color-gold`. À côté, le **logo texte** "GUMÜÇROYAL" dans une belle police (serif premium ou un lettrage doré). Garder le tréma `Ü` et la cédille `Ç` comme signature visuelle.
- Prévoir un composant `<Logo />` réutilisable (SVG ou texte stylé) + placeholder pour le vrai logo.

## Composants clés (design tokens)
- **Boutons CTA** : fond dégradé or (`--color-gold` → `--color-gold-soft`), texte noir, coins arrondis doux, ombre dorée subtile au hover, micro-animation (scale 1.02). CTA = élément le plus visible de chaque écran.
- **Badges de réassurance** : pastilles sombres bord or, icône + texte court arabe.
- **Cartes produit** : surface `--color-surface`, image, titre serif, prix, étoiles, CTA.
- **Étoiles** : or, demi-étoiles supportées, note + nombre d'avis.
- **Drawer panier** : slide depuis le côté, fond `--color-surface`, overlay sombre.
- **Popups** (checkout, upsell) : centrés, fond sombre, bord or, animation d'apparition.

## Motion
- Apparition au scroll (fade + translate léger) sur les sections.
- Chargement de page : reveal en cascade du hero.
- Hover : boutons et cartes réagissent (élévation, glow or).
- Utiliser **Framer Motion** (React) pour orchestrer (voir libs dans 09).
- Rester fluide et rapide — pas d'animations lourdes qui ralentissent le mobile.

## Layout & composition (desktop pro)
- Sections **alternées texte/image** : une section = texte à droite / image à gauche, la suivante = l'inverse. (Adapter au RTL.)
- Espacement généreux, rythme vertical clair.
- Largeur de contenu max ~1200px, centrée.
- Grilles : produits en grille responsive (1 col mobile, 2-3 cols desktop).

## Responsive (mobile-first)
- Breakpoints Tailwind standard (sm, md, lg, xl).
- Mobile : header compact (logo + burger + cart), sections empilées, CTA collant en bas sur les pages produit (sticky "زيدي للسلة").
- Desktop : sections alternées, header complet avec menu.
- Tester sur viewport 360–414px (mobile marocain courant).

## Iconographie
- Icônes fines et élégantes (ex. lucide-react), teintées or ou crème.
- Pas d'emojis dans l'UI structurelle (ok ponctuellement dans les avis clients).

## Images (placeholders)
- Hero homepage, 3-4 images par page produit, visuels collection : **placeholders temporaires** (ratio correct, fond sombre, mention "image à remplacer"). Le client fournira les vraies.
- Toujours `next/image` avec width/height pour éviter le layout shift.
