# 08 — Checkout & COD Flow (Cart Drawer → Popup → Upsell → Thank You)

Parcours complet, étape par étape. Tout est **COD**, formulaire **2 champs**.

## Étape 1 — Add to cart (depuis page produit)
- La cliente choisit une **offre** (1/2/3 pièces) → clique **« زيدي للسلة »**.
- L'offre choisie (produit + quantité + prix) est ajoutée au panier.
- Le **cart drawer** s'ouvre automatiquement.
- Tracking : `AddToCart`.

## Étape 2 — Cart Drawer (tiroir latéral)
Contenu :
- Liste des articles (image, nom, offre, prix, quantité +/-, supprimer).
- **Cross-sells "كمّلي إطلالتك"** : 1-2 produits complémentaires avec bouton "زيدي" (ajout en 1 clic).
- Sous-total + économies.
- Réassurance : COD · توصيل · ضمان.
- **CTA « كمّلي الطلب »** → ouvre le **checkout popup**.
- La cliente peut ajuster quantités, ajouter des cross-sells, ou continuer ses achats.

## Étape 3 — Checkout Popup (modal)
Contenu :
- **Récapitulatif de commande** (order summary) : articles, quantités, total.
- **Social proof** : "+X clientes ont commandé aujourd'hui", mini-avis, ★ 4.8.
- **Scarcity** : « الكمية محدودة » / petit compte à rebours.
- **Formulaire — 2 champs uniquement** :
  - **الاسم الكامل** (nom complet) — requis, texte.
  - **رقم الهاتف** (téléphone) — requis, **doit valider un numéro marocain**.
- **CTA « تأكيد الطلب »**.

### Validation du numéro marocain (frontend + backend)
- Accepter les formats locaux : `06XXXXXXXX`, `07XXXXXXXX` (10 chiffres commençant par 06/07), et l'international `+2126XXXXXXXX` / `+2127XXXXXXXX` / `2126…` / `2127…`.
- Normaliser en interne au format **E.164** : `+2126XXXXXXXX` (pour CAPI).
- Rejeter tout ce qui n'est pas un mobile marocain valide, avec message darija : « دخّلي رقم هاتف مغربي صحيح ».
- Regex indicative (à affiner) : `^(?:\+212|212|0)([67])\d{8}$`.

## Étape 4 — Upsell post-formulaire (10–15s, compte à rebours)
- Dès que le form est valide et CTA cliqué :
  - Créer la commande "de base" (ou la garder en attente — voir backend) et **afficher l'upsell**.
  - **Produit pertinent à 69 DH** (unique discount du site), avec **compte à rebours 10–15s** visible.
  - Boutons : **« زيديها لطلبي (69 د.م) »** / **« لا شكراً »**.
  - Si accepté → ajouter l'article 69 DH à la commande.
  - À expiration du timer OU après choix → aller à la **thank you page**.
- Tracking : à la confirmation finale → `Purchase` (côté navigateur + CAPI, même `event_id`).

## Étape 5 — Thank You page (`/merci`)
- Confirmation : « طلبك توصل! غادي نعيطو ليك قريب نأكدو 🤍 ».
- Récap commande + numéro de commande.
- Réassurance : étapes suivantes (appel de confirmation, délai livraison).
- WhatsApp pour toute question.
- Cross-sell soft / retour à la collection.
- Tracking : `Purchase` confirmé ici (dédupliqué avec CAPI).

## Envoi de la commande
- À la confirmation finale, le frontend envoie la commande au **backend** (`POST /api/orders`).
- Le backend : valide, normalise le téléphone, enregistre en **PostgreSQL**, déclenche le **webhook Google Sheet**, et envoie les events **CAPI** (Meta/TikTok/Snap).
- Voir 10 (backend), 11 (tracking), 12 (Google Sheet).

## Données de commande à capturer
- Nom, téléphone (normalisé E.164 + version locale), articles (produit, offre, qté, prix unitaire), upsell (oui/non), total, devise (MAD), source/UTM si dispo, fbp/fbc/ttclid/sc click id si dispo, event_id, timestamp, page d'origine, user agent, IP.
