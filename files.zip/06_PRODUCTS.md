# 06 — Produits, Prix, Offres, Cross-sells, Upsell

> **IMPORTANT prix :** les montants ci-dessous sont des **valeurs de départ à mettre dans la config** (centralisées, faciles à changer). Le client ajustera. Tout est en **MAD**. Devise affichée : « د.م » ou « DH ».

## Les 3 produits

### Produit 1 — Bague Lien Éternel By GUMÜÇ Royal
- **Slug** : `bague-lien-eternel`
- **Heading (FR)** : Bague Lien Éternel
- **Sous-marque** : By GUMÜÇ Royal
- **Subheading (darija)** : « المايو الأيقوني، بإطلالة ملكية كتلفت الأنظار »
- **Description** : Le maillon iconique réinventé en anneau ouvert, pavé de zircons taille brillant avec une pierre solitaire en son centre. Acier inoxydable doré à l'or fin — un éclat qui ne ternit jamais.
- **Prix de base** : 249 DH (prix barré "valeur" : 399 DH)
- **Cross-sell prioritaire** : Collier Trèfle de Lumière.

### Produit 2 — Collier Trèfle de Lumière By GUMÜÇ Royal
- **Slug** : `collier-trefle-de-lumiere`
- **Heading (FR)** : Collier Trèfle de Lumière
- **Subheading (darija)** : « رمز الحظ، بلمسة فخامة كتزيد بريق لرقبتك »
- **Description** : Une double chaîne délicate ponctuée de quatre trèfles porte-bonheur pavés de zircons étincelants. L'élégance discrète qui se remarque, en acier inoxydable doré à l'or fin.
- **Prix de base** : 269 DH (barré : 429 DH)
- **Cross-sell prioritaire** : Bague Lien Éternel.

### Produit 3 — Bague Double Signature By GUMÜÇ Royal
- **Slug** : `bague-double-signature`
- **Heading (FR)** : Bague Double Signature
- **Subheading (darija)** : « تصميم جريء وأنثوي، مفتوح وقابل للتعديل »
- **Description** : Un design architectural à deux extrémités pavées de zircons, ferme et résolument féminin. Forme ouverte ajustable, en acier inoxydable doré à l'or fin.
- **Prix de base** : 229 DH (barré : 369 DH)
- **Cross-sell prioritaire** : Collier Trèfle de Lumière.

## Offres par paliers (sur chaque page produit) — moteur d'AOV
Afficher un **sélecteur d'offres** (cartes radio). Exemple pour une bague :
| Offre | Contenu | Prix | Mise en avant |
|-------|---------|------|---------------|
| Offre 1 | 1 pièce | 249 DH | — |
| Offre 2 | 2 pièces | 399 DH (au lieu de 498) | **"الأكثر طلباً"** ✅ pré-sélectionnée |
| Offre 3 | 3 pièces | 549 DH (au lieu de 747) | **"أحسن ثمن"** |

- L'offre du milieu est **pré-sélectionnée** (ancrage). 
- Montrer l'économie réalisée (« كتربحي 99 د.م »).
- Pour le collier, paliers équivalents adaptés au prix.
- **Ces prix/paliers sont dans un fichier de config produits** (voir 09), pas en dur dans les composants.

## Cross-sells (dans le cart drawer)
Quand le drawer s'ouvre, afficher **"كمّلي إطلالتك"** avec 1–2 produits complémentaires (le cross-sell prioritaire du produit + un autre). Bouton "زيدي" pour ajouter en un clic. Objectif : monter le panier.

## Upsell post-formulaire (le SEUL discount produit)
Après que la cliente a rempli le formulaire (nom + tél valides) et cliqué le CTA :
- Afficher un **upsell limité dans le temps (10–15 secondes, compte à rebours visible)**.
- Produit pertinent (ex. après une bague → l'autre bague, ou le collier) à **69 MAD** (prix choc, c'est l'unique endroit avec une vraie remise).
- Deux boutons : **"زيديها لطلبي (69 د.م)"** / **"لا شكراً، كمّلي"**.
- Si acceptée → ajoutée à la commande. Dans tous les cas → **thank you page** (`/merci`).
- Le compte à rebours qui expire → enchaîne automatiquement vers la thank you page (ou ferme l'upsell).

## Règles produit transverses
- Toujours : matière "acier inoxydable 316L doré à l'or fin", pierres "zircons / cristaux" — **jamais "or"/"diamant"**.
- Badges sous le prix : "ما كيصدأش" · "ما كيحسّسش" · "الدفع عند الاستلام" · "ضمان 30 يوم".
- Réutiliser les produits **à plusieurs endroits** : home (vedettes), collection, cross-sell, upsell, "كمّلي إطلالتك".
