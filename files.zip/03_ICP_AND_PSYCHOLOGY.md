# 03 — ICP, Psychologie & Langage (Darija)

## Client cible (ICP)
**Femme marocaine, 18–45 ans** (cœur 22–38), urbaine/péri-urbaine, active sur Instagram/TikTok/Snapchat. Elle aime se faire belle, suit la mode, s'achète des bijoux **pour elle-même** (pas seulement en cadeau). Budget moyen mais prête à payer pour quelque chose de **beau, durable et valorisant**.

### Ses douleurs (pains)
- A déjà acheté des bijoux pas chers qui ont **noirci / verdi la peau** ou **terni** en quelques jours → déception, méfiance.
- Peur de **se faire avoir** en achetant en ligne (qualité ≠ photo, arnaque).
- Veut du **luxe** mais l'or véritable est **trop cher**.
- Veut être **remarquée / se sentir spéciale** sans en faire trop.

### Ses désirs (gains)
- Se sentir **élégante, royale, confiante**.
- Un bijou **qui dure** et qu'elle peut porter tous les jours (douche, été, transpiration).
- **Acheter en confiance** : payer à la livraison, voir avant de payer.
- Un bijou qui a une **histoire / un nom** (pas un truc anonyme).

## Comment vendre par l'émotion (sans jouer sur l'insécurité)
On vend **le résultat fier et la confiance** : « كتحسي بفخر », « إطلالة ملكية », « بريق كيلفت الأنظار ».
On **ne vend pas** le complexe (« راكي ما كافياش »). L'émotion est attachée à la **transformation positive et à la durabilité**, ce qui protège le **taux de livraison** (achat fier = colis réceptionné).

## Comment tout backer par la preuve
Chaque promesse émotionnelle est immédiatement suivie d'une **preuve** :
- "Éclat qui dure" → **acier 316L + dorure or fin** (raison de croire).
- "Ne noircit pas la peau" → **hypoallergénique, testé**.
- "Des milliers de femmes l'adorent" → **avis + photos + note 4.8★**.
- "Zéro risque" → **paiement à la livraison + garantie 30 jours**.

## Banque de copy en Darija (alphabet arabe) — à réutiliser
> L'AI coder insère ces formules dans les bons emplacements. Garder les noms de produits en français.

**Accroches / hooks :**
- « بريق ذهبي كيدوم… بلا ما يصدأ ولا يكحّل اليد »
- « إطلالة ملكية، بثمن في المتناول »
- « مجوهرات كتختار بيها راسك… كل نهار »
- « جمال كيبقى، ماشي غير تصويرة »

**Réassurance :**
- « الدفع عند الاستلام — خلّصي منين توصلك »
- « توصيل لجميع مدن المغرب »
- « ضمان 30 يوم — راضية ولا فلوسك »
- « ستانلس ستيل 316L — ما كيصدأش، ما كيحسّسش »
- « تغليف هدية فاخر مجاني »

**Urgence / rareté :**
- « الكمية محدودة »
- « العرض كيسالي قريب »
- « بقاو غير X قطع فالستوك »

**CTA :**
- « طلبي دابا » (Commander maintenant)
- « زيدي للسلة » (Ajouter au panier)
- « كمّلي الطلب » (Finaliser la commande)

**Social proof (exemples d'avis à afficher, remplaçables) :**
- « جا أحسن من التصويرة، ما صدّاش حتى مع الما 🤍 » — سعاد، الدار البيضاء
- « لبستو نهار العرس وكلشي سولني فينو شريتو » — هند، الرباط
- « جودة خيالية بالنسبة للثمن، غادي نعاود نطلب » — أمل، مراكش

## Règle de langue & direction
- Site **RTL** (dir="rtl"). Texte émotionnel/UI en **arabe darija**.
- Noms de produits, "By GUMÜÇ Royal", et termes premium en **français/latin** (restent en LTR inline).
- Police arabe lisible et élégante + police latine premium (voir 04_DESIGN_SYSTEM.md).
