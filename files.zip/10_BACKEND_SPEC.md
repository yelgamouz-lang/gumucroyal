# 10 — Backend Spec (FastAPI + PostgreSQL)

## Stack
- **Python 3.12+**, **FastAPI**, **Uvicorn/Gunicorn**.
- **SQLAlchemy 2.x** + **Alembic** (migrations) OU SQLModel — au choix, mais **migrations automatiques au démarrage**.
- **psycopg** (driver PostgreSQL).
- **httpx** (appels CAPI sortants, async).
- **pydantic v2** (validation des payloads).
- **python-dotenv** pour le local.

## Structure de dossiers (backend/)
```
backend/
  app/
    main.py                 # app FastAPI, CORS, startup -> run migrations
    config.py               # settings depuis env (pydantic-settings)
    database.py             # engine, session
    models.py               # Order, OrderItem (SQLAlchemy)
    schemas.py              # pydantic (OrderCreate, OrderItem, etc.)
    routers/
      orders.py             # POST /api/orders, GET /api/health
    services/
      phone.py              # validate/normalize MA phone -> E.164
      sheets.py             # webhook vers Google Apps Script
      tracking_capi.py      # Meta + TikTok + Snapchat CAPI (hashing, dedup)
      hashing.py            # sha256 normalize helpers
    migrations/             # Alembic
  requirements.txt
  alembic.ini
  .env.example
  Dockerfile
```

## Endpoints
- `GET /api/health` → `{status: "ok"}` (pour EasyPanel healthcheck).
- `POST /api/orders` → reçoit la commande du frontend.
  - Valide le payload (pydantic) + **valide/normalise le téléphone MA**.
  - Rate-limit (anti-spam) par IP.
  - Enregistre `Order` + `OrderItem[]` en PostgreSQL.
  - Déclenche (en tâche de fond / async) :
    1. **Webhook Google Sheet** (voir 12).
    2. **CAPI** Meta + TikTok + Snapchat (voir 11) — event `Purchase`, avec le **même event_id** que le pixel web.
  - Répond `{ ok: true, order_id, event_id }`.

## Modèle de données (PostgreSQL)
**orders**
| colonne | type | note |
|--------|------|------|
| id | UUID PK | |
| created_at | timestamptz | |
| full_name | text | |
| phone_local | text | format local 06/07… |
| phone_e164 | text | +212… (pour CAPI) |
| total_amount | numeric(10,2) | MAD |
| currency | text | "MAD" |
| has_upsell | boolean | |
| status | text | "new" par défaut |
| source | text | utm/source si dispo |
| event_id | text | dédup tracking |
| fbp | text | nullable |
| fbc | text | nullable |
| ttclid | text | nullable |
| sc_click_id | text | nullable |
| user_agent | text | |
| ip | text | |
| page_url | text | |

**order_items**
| colonne | type |
|--------|------|
| id | UUID PK |
| order_id | UUID FK → orders.id |
| product_slug | text |
| product_name | text |
| offer_label | text (ex: "2 pièces") |
| quantity | int |
| unit_price | numeric(10,2) |
| is_upsell | boolean |

## Migrations automatiques au démarrage
- Au `startup` de FastAPI : exécuter `alembic upgrade head` (ou créer les tables si absentes) **automatiquement**, en utilisant `DATABASE_URL`.
- Doit être idempotent (ne casse pas si déjà à jour).

## CORS
- Autoriser l'origine `https://gumucroyal.store` (et `http://localhost:3000` en dev).

## Sécurité
- Ne jamais logger `phone_*` en clair.
- Hasher les PII **uniquement** pour CAPI.
- Valider strictement les entrées.
- Secrets (tokens CAPI, webhook secret) **uniquement** en variables d'env backend.

## Variables d'env backend (voir 13 pour le .env.example complet)
`DATABASE_URL`, `FRONTEND_ORIGIN`,
`GOOGLE_SHEET_WEBHOOK_URL`, `GOOGLE_SHEET_WEBHOOK_SECRET`,
`META_PIXEL_ID`, `META_CAPI_TOKEN`, `META_TEST_EVENT_CODE`(optionnel),
`TIKTOK_PIXEL_ID`, `TIKTOK_CAPI_TOKEN`, `TIKTOK_TEST_EVENT_CODE`(optionnel),
`SNAPCHAT_PIXEL_ID`, `SNAPCHAT_CAPI_TOKEN`, `SNAPCHAT_TEST_EVENT_CODE`(optionnel).
