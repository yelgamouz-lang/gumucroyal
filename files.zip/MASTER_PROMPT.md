# 🎯 MASTER ULTRA PROMPT — À donner à Claude Code

> Copie tout ce qui suit et donne-le à Claude Code, dans le dossier qui contient le dossier `docs/`.

---

Tu es un ingénieur full-stack senior spécialisé en e-commerce DTC à très haute conversion. Tu vas construire, de A à Z, une boutique e-commerce **brandée** nommée **GUMÜÇROYAL** (bijoux femme, Maroc, paiement à la livraison).

## AVANT TOUT — Lis la documentation
Un dossier `docs/` est présent à la racine. **Lis-le INTÉGRALEMENT et dans l'ordre AVANT d'écrire la moindre ligne de code.** Il contient toute la spécification :

- `docs/00_README.md` — index + règles d'or (commence par lui)
- `docs/01_PROJECT_OVERVIEW.md` — vision, stack, contraintes
- `docs/02_BRAND_POSITIONING.md` — positionnement "maison, pas dropshipper"
- `docs/03_ICP_AND_PSYCHOLOGY.md` — client cible + copy darija
- `docs/04_DESIGN_SYSTEM.md` — couleurs, polices, logo, layout, RTL
- `docs/05_INFORMATION_ARCHITECTURE.md` — toutes les pages, header, footer
- `docs/06_PRODUCTS.md` — les 3 produits, prix, offres, cross-sells, upsell
- `docs/07_CRO_AND_CONVERSION.md` — sections de vente, CRO, social proof
- `docs/08_CHECKOUT_AND_COD_FLOW.md` — cart drawer → popup → upsell → merci
- `docs/09_FRONTEND_SPEC.md` — Next.js/React/Tailwind, structure, règles de code
- `docs/10_BACKEND_SPEC.md` — FastAPI, PostgreSQL, migrations auto, endpoints
- `docs/11_TRACKING_PIXELS_CAPI.md` — Meta/TikTok/Snap pixels + CAPI, hashing, dedup
- `docs/12_GOOGLE_SHEET_INTEGRATION.md` — webhook → Google Sheet + Apps Script
- `docs/13_DEPLOYMENT_EASYPANEL.md` — Docker, GitHub, EasyPanel, env.example
- `docs/14_DELIVERABLES_CHECKLIST.md` — la liste exacte des livrables
- `docs/sheet_template.csv`, `docs/products.csv` — données de référence

Après lecture, fais un court plan d'exécution, puis construis.

## CE QUE TU DOIS CONSTRUIRE (résumé — les détails sont dans docs/)

**Marque & ton**
- Boutique **brandée premium** : GUMÜÇROYAL doit paraître propriétaire de ses bijoux, **jamais** un dropshipper.
- Site **RTL**, copy émotionnel en **darija (alphabet arabe)**, noms de produits en **français premium**.
- Esthétique luxe sombre & doré (noir profond + or `#C9A227`), inspirée des visuels produits (fond noir, fumée, or).
- **Honnêteté produit obligatoire** : "acier inoxydable 316L doré à l'or fin" et "zircons/cristaux" — **jamais "or massif" ni "diamants"** (faux descriptif = ban pub + retours COD).

**Frontend (Next.js App Router + React + TypeScript + TailwindCSS)**
- Pages : Home, Collection, 3× pages produit (`/produit/[slug]`), About, Contact, Merci, pages légales.
- Header (logo dans un cercle couleur or + logo texte "GUMÜÇROYAL" en police premium, menu, cart) + Footer complet.
- Home : hero, barre de réassurance, section marque (texte/image alternés), produits vedettes, "pourquoi nous" (preuve), social proof (avis + photos + 4.8★), "comment ça marche" (rassure COD), CTA final.
- Sections desktop **alternées texte/image puis inversées** (appliquer à toutes les pages qui s'y prêtent).
- Page produit (CRO 12/10) : galerie 3-4 images + product card (heading, subheading, ★, prix barré + offre + économie, **sélecteur d'offres 1/2/3 pièces** avec celle du milieu pré-sélectionnée, scarcity, CTA), puis sections bénéfices / matière (316L) / avis / comparatif / FAQ / garantie. **CTA sticky sur mobile.**
- Libs : Framer Motion (animations), lucide-react (icônes), zustand (cart), react-hook-form + zod (form).
- Données des 3 produits **centralisées** dans `lib/products.ts`.
- Images = **placeholders temporaires** partout.
- Responsive mobile-first, desktop pro.

**Parcours d'achat (COD, détaillé dans docs/08)**
1. Choix d'une offre → "زيدي للسلة" → ouvre le **cart drawer**.
2. Cart drawer avec **cross-sells "كمّلي إطلالتك"** (ajout 1 clic) → CTA "كمّلي الطلب".
3. **Checkout popup** : order summary + social proof + scarcity + **formulaire 2 champs uniquement** (nom + téléphone). Le téléphone doit **valider un numéro marocain** (06/07 ou +212…) et être normalisé en **E.164**.
4. CTA form → **upsell limité 10–15s avec compte à rebours** : produit pertinent à **69 MAD** (seul discount du site) → accepter/refuser.
5. **Thank you page** `/merci`.
6. La commande part vers le backend.

**Backend (Python FastAPI + PostgreSQL)**
- `GET /api/health`, `POST /api/orders`.
- Valide + normalise le téléphone MA (E.164), enregistre Order + OrderItems en PostgreSQL.
- Déclenche : **webhook Google Sheet** + **CAPI** (Meta/TikTok/Snap) en tâche de fond.
- **Migrations DB automatiques au démarrage.**
- Rate-limiting sur `/api/orders`. CORS pour `gumucroyal.store`.

**Tracking (docs/11 — spécs vérifiées)**
- Pixels web Meta + TikTok + Snapchat, chargés en **deferred** (perf).
- **CAPI serveur** pour Meta + TikTok + Snapchat.
- **Déduplication** : même `event_id` partagé entre pixel web et CAPI pour chaque event (surtout `Purchase`).
- **Hashing** : pixel web ne hash rien ; CAPI hash les PII en **SHA-256** après normalisation. Téléphone en **E.164** (avec `+212`) puis SHA-256. Identifiants techniques (fbp, fbc, ttclid, sc_click_id, IP, UA) en clair.
- Vérifie la version courante des endpoints CAPI au moment du build et prévois les Test Event Codes.

**Google Sheet (docs/12)**
- Webhook backend → Google Apps Script → écrit une ligne dans le Sheet.
- Livrer `google-apps-script.gs` (avec vérif d'un secret partagé) + `sheet_template.csv`.
- Colonnes : order_id, created_at, full_name, phone_local, phone_e164, items, total_amount, currency, has_upsell, source, page_url, status.

**Déploiement (docs/13)**
- **Docker** pour frontend ET backend.
- `frontend/.env.example` et `backend/.env.example` avec **toutes** les variables à mettre dans EasyPanel.
- `DATABASE_URL` interne EasyPanel :
  `postgres://gumucroyal:gumucroyal@gumucroyal_database:5432/gumucroyal?sslmode=disable`
- Domaines : front `gumucroyal.store`, back `api.gumucroyal.store`.
- README racine avec instructions complètes (install, env, Docker, EasyPanel, Apps Script, pixels/CAPI, tests).

## LIVRABLES EXACTS (voir docs/14 pour la checklist complète)
```
/
├── frontend/              # Next.js + React + Tailwind (Docker, .env.example)
├── backend/               # FastAPI + PostgreSQL (Docker, .env.example, migrations auto)
├── google-apps-script.gs  # script Google Sheet
├── sheet_template.csv     # colonnes du Sheet
├── products.csv           # référence produits
├── docs/                  # la doc
├── README.md              # install + déploiement EasyPanel pas à pas
└── .gitignore
```

## EXIGENCES DE QUALITÉ (non négociables)
- Code **TypeScript strict** (front) et **typé pydantic** (back), propre, commenté là où utile.
- Tout configurable par **variables d'env** — aucune valeur secrète en dur, aucun besoin de modifier le code pour déployer.
- **Performance** : pixels deferred, images optimisées, build prod.
- **RTL + darija** corrects, noms produits en français.
- **Aucun** "or massif"/"diamant", **aucun** signe de dropshipping.
- Prêt à `git push` puis déployer sur EasyPanel sans étape manuelle de code.
- À la fin : un **README** clair qui me permet de tout brancher (env, domaines, Sheet, pixels) et de tester une commande de bout en bout.

Commence par lire `docs/`, propose ton plan, puis construis l'ensemble. Si un détail des API CAPI a changé depuis la doc, vérifie et adapte en gardant l'intention (dédup + hashing corrects).
